package com.example.popi1.cainstructionquiz;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.Random;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.view.*;


public class MainActivity extends AppCompatActivity {

    private TextView print_epilogis;
    private TextView apotelesma;
    private EditText apantisi;
    private Random math = new Random();
    private int c;
    private int apa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        print_epilogis =
                (TextView) findViewById(R.id.print_epilogis);

        apotelesma =
                (TextView) findViewById(R.id.apotelesma);

        apantisi =
                (EditText)findViewById(R.id.apantisi);
        apantisi.addTextChangedListener(answerTextWatcher);
        Button button1 = (Button) findViewById(R.id.sum);
        button1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int a, b;

                a = math.nextInt(100);
                b = math.nextInt(100);

                print_epilogis.setText("Πόσο κάνει " + a + "+" + b + "?");
                c = a + b;
                apantisi.setText(null);
                apotelesma.setText(null);


            }
        });

        final Button button2 = (Button) findViewById(R.id.sub);
        button2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int a, b;
                    a = math.nextInt(100);
                    b = math.nextInt(100);
                    if (a >= b) {
                        print_epilogis.setText("Πόσο κάνει " + a + "-" + b + "?");
                        c = a - b;
                    }else{
                        print_epilogis.setText("Πόσο κάνει " + b + "-" + a + "?");
                        c = b - a;
                    }
                apantisi.setText(null);
                apotelesma.setText(null);

            }
        });

        final Button button3 = (Button) findViewById(R.id.multi);
        button3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int a, b;

                a = math.nextInt(11);
                b = math.nextInt(11);
                print_epilogis.setText("Πόσο κάνει " + a + "*" + b + "?");
                c = a * b;
                apantisi.setText(null);
                apotelesma.setText(null);
            }
        });


    }
    private TextWatcher answerTextWatcher = new TextWatcher()
    {
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count)
        {

            try
            {
                apa =  Integer.parseInt(s.toString());
            }
            catch (NumberFormatException e)
            {
                apa = -1;
            }

            if(apa != -1)
            {
                if(apa==c)
                    apotelesma.setText("Μπράβο!!");
                else
                    apotelesma.setText("Προσπάθησε ξανά!");
            }

        }

        @Override
        public void afterTextChanged(Editable s)
        {
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after)
        {
        }
    };


}
